//
//  OtherPlayer.cpp
//  guyue
//
//  Created by dsh on 15/1/8.
//
//

#include "OtherPlayer.h"
OtherPlayer::OtherPlayer()
{
    
}

OtherPlayer::~OtherPlayer()
{
    
}
