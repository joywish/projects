//
//  gameConfig.h
//  guyue
//
//  Created by dsh on 15/1/8.
//
//

#ifndef guyue_gameConfig_h
#define guyue_gameConfig_h

#define MAIN_FONT_NAME "Arial"

#endif
