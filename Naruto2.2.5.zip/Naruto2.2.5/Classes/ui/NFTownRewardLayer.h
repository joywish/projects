#ifndef _NF_TOWN_REWARD_LAYER_HEAD_
#define _NF_TOWN_REWARD_LAYER_HEAD_

#include "../publicdef/PublicDef.h"

/************************************************************************/
/*			��������                                                                    */
/************************************************************************/
class CNFTownRewardLayer : public CCLayerColor
{
protected:
	//��ǩ
	enum 
	{
		enTagPro = 1,
		enTagLight,
		enTagLabel,
	};

public:
	static CNFTownRewardLayer * CreateLayer();

	//���ý�����
	void SetPro(float fRate);

protected:
	virtual bool init();     

	//����
	virtual bool ccTouchBegan(CCTouch *pTouch, CCEvent *pEvent);
	virtual void ccTouchMoved(CCTouch *pTouch, CCEvent *pEvent);
	virtual void ccTouchEnded(CCTouch *pTouch, CCEvent *pEvent);

	virtual void onExit();

};


#endif