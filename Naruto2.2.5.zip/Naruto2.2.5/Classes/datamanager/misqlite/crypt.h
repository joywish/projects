

int aes_encrypt(unsigned char* pData, unsigned int data_len,
	unsigned char* key, unsigned int len_of_key);

int aes_decrypt(unsigned char* pData, unsigned int data_len,
	unsigned char* key, unsigned int len_of_key);
